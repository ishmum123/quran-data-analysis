The Quran
Modern English Translation
Verse by Verse

Translated by Talal Itani
www.ClearQuran.com

Available in two editions. This edition (A) uses the word 'Allah' to refer to the Creator. Edition (B) uses the word 'God'.

These files can be shared and distributed
Provided under the Creative Commons License
Attribution-NonCommercial-NoDerivs

